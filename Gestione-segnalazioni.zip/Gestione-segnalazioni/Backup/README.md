# Gestione-segnalazioni
La soluzione di Gestione Segnalazione gestisce l’intero processo di lavorazione di una particolare accadimento (guasto/incidente) a partire dalla segnalazione da parte di Operatori  predisposti a rilevarlo,  attraverso uno smartphone, o qualsiasi altro dispositivo, passando allo smistamento e  presa in carico dai vari uffici preposti alla risoluzione, fino alla produzione automatica di un documento denominato rapportino di intervento che viene archiviato ed inviato tramite email ai soggetti interessati.

PER MAGGIORI INFO: [Readme - Gestione Accadimento.pdf](https://github.com/Jamio-openwork/Gestione-segnalazioni/files/6816740/Readme.-.Gestione.Accadimento.pdf)
![IMGReadme](https://user-images.githubusercontent.com/86653778/125643516-1ea51967-6f82-4846-a1cc-5d838acf2722.png)
